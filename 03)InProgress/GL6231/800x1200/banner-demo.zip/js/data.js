window.sctContent = {
  html_vw: "Ihr Volkswagen Partner",
  html_dealer_headline_0_start: "Autohaus Carl Bondbauer GmbH & Co. KG langer Firmenzusatz",
  html_dealer_headline_0: "Autohaus Carl Bondbauer GmbH & Co. KG",
  html_dealer_address_line_0: "Musterstraße 5",
  html_dealer_address_line_1: "12345 Musterstadt",
  html_legal_text: "<sup>1</sup> Fahrzeugabbildung zeigt Sonderausstattungen. Bildliche Darstellungen können vom Auslieferungsstand abweichen. Änderungen und Irrtümer vorbehalten. Stand 04/2024.",

  _landingpage: 'https://www.socoto.com'
};









